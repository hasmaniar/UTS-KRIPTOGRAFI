from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import hashlib

# Membuat key dari password
def generate_key(password):
    return hashlib.sha256(password.encode()).digest()

# Enkripsi file
def encrypt_file(input_file, output_file, password):
    key = generate_key(password)

    with open(input_file, 'rb') as f:
        data = f.read()

    iv = get_random_bytes(16)

    cipher = AES.new(key, AES.MODE_CBC, iv)

    encrypted_data = cipher.encrypt(
        pad(data, AES.block_size)
    )

    with open(output_file, 'wb') as f:
        f.write(iv)
        f.write(encrypted_data)

    print("File berhasil dienkripsi!")

# Dekripsi file
def decrypt_file(input_file, output_file, password):
    key = generate_key(password)

    with open(input_file, 'rb') as f:
        iv = f.read(16)
        encrypted_data = f.read()

    cipher = AES.new(key, AES.MODE_CBC, iv)

    decrypted_data = unpad(
        cipher.decrypt(encrypted_data),
        AES.block_size
    )

    with open(output_file, 'wb') as f:
        f.write(decrypted_data)

    print("File berhasil didekripsi!")

# Menu program
print("=== AES PDF Encryption ===")
print("1. Encrypt PDF")
print("2. Decrypt PDF")

choice = input("Pilih menu: ")
password = input("Masukkan password: ")

if choice == '1':
    input_file = input("Masukkan nama file PDF: ")
    output_file = "encrypted_" + input_file

    encrypt_file(input_file, output_file, password)

elif choice == '2':
    input_file = input("Masukkan file terenkripsi: ")
    output_file = "decrypted.pdf"

    decrypt_file(input_file, output_file, password)

else:
    print("Pilihan tidak valid!")